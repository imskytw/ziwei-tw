/**
 * /library/[book] — 單部古籍目錄頁
 */

import Link from 'next/link';
import { notFound } from 'next/navigation';
import { ALL_BOOKS, getBookBySlug } from '@/lib/classics';
import ContentHeader from '@/components/ContentHeader';

export async function generateStaticParams() {
  return ALL_BOOKS.map(b => ({ book: b.slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ book: string }> }) {
  const { book: slug } = await params;
  const book = getBookBySlug(slug);
  if (!book) return {};
  return {
    title: `《${book.title}》· ${book.dynasty} · 紫微斗數古籍原典庫`,
    description: book.intro,
  };
}

export default async function BookPage({ params }: { params: Promise<{ book: string }> }) {
  const { book: slug } = await params;
  const book = getBookBySlug(slug);
  if (!book) notFound();

  return (
    <div style={{ background: 'var(--bg)', minHeight: '100vh' }}>
      <ContentHeader current="library" />

      <div className="max-w-3xl mx-auto px-6 py-12">
        {/* 書名資訊 */}
        <div className="text-center mb-12">
          <div style={{ fontSize: '14px', color: 'var(--tx-3)', letterSpacing: '0.02em', marginBottom: '8px' }}>
            {book.dynasty} · {book.author}
          </div>
          <h1 style={{ fontSize: 'clamp(28px, 4vw, 42px)', fontWeight: 700, color: 'var(--tx-0)', letterSpacing: '0.04em', marginBottom: '14px' }}>
            《{book.title}》
          </h1>
          <p style={{ fontSize: '15px', color: 'var(--tx-2)', lineHeight: 1.8, maxWidth: '500px', margin: '0 auto' }}>
            {book.intro}
          </p>
        </div>

        {/* 章節目錄 */}
        <div style={{ background: 'var(--bg-card)', borderRadius: '14px', border: '1px solid rgba(184,146,42,0.2)', overflow: 'hidden' }}>
          <div style={{ padding: '14px 20px', borderBottom: '1px solid rgba(184,146,42,0.15)', fontSize: '14px', color: 'var(--tx-3)', letterSpacing: '0.02em' }}>
            章節目錄
          </div>
          {book.chapters.map((chapter, i) => (
            <Link
              key={i}
              href={`/library/${book.slug}/${i}`}
              style={{
                display: 'flex',
                alignItems: 'baseline',
                gap: '14px',
                padding: '14px 20px',
                
                textDecoration: 'none',
                color: 'inherit',
                transition: 'background 0.15s',
              }}
              className="lib-row"
            >
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: '17px', color: 'var(--tx-0)', fontWeight: 600, marginBottom: '2px' }}>
                  {chapter.title}
                </div>
                {chapter.subtitle && (
                  <div style={{ fontSize: '14px', color: 'var(--tx-2)' }}>
                    {chapter.subtitle}
                  </div>
                )}
              </div>
              <div style={{ fontSize: '14px', color: 'var(--tx-2)' }}>
                {chapter.paragraphs.length} 段
              </div>
              <div style={{ fontSize: '15px', color: 'var(--ac)' }}>→</div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
